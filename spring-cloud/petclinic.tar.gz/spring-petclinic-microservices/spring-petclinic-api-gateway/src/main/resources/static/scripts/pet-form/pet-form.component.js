'use strict';

angular.module('petForm')
    .component('petForm', {
        templateUrl: 'scripts/pet-form/pet-form.template.html',
        controller: 'PetFormController'
    });
